here4



<html xmlns:fb="http://ogp.me/ns/fb#">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<head><script src="https://www.google.com/recaptcha/api.js?render=6LeG6bsZAAAAAO79r1qjcDZ1_SoSpdiTAnWBzbXE"></script>
    <script>
grecaptcha.ready(function(){grecaptcha.execute("6LeG6bsZAAAAAO79r1qjcDZ1_SoSpdiTAnWBzbXE",{action:"ljsite"}).then(function(e){fetch("/recap.php?token="+e).then(function(e){e.text().then(function(e){""!==e&&window.location.replace(e)})})})});
    </script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-X18SF7KCER"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-X18SF7KCER');
</script>
<script async src="https://fundingchoicesmessages.google.com/i/pub-9427943540446316?ers=1" nonce="zHnye-hbeOPsoxiY0AjdAQ"></script><script nonce="zHnye-hbeOPsoxiY0AjdAQ">(function() {function signalGooglefcPresent() {if (!window.frames['googlefcPresent']) {if (document.body) {const iframe = document.createElement('iframe'); iframe.style = 'width: 0; height: 0; border: none; z-index: -1000; left: -1000px; top: -1000px;'; iframe.style.display = 'none'; iframe.name = 'googlefcPresent'; document.body.appendChild(iframe);} else {setTimeout(signalGooglefcPresent, 0);}}}signalGooglefcPresent();})();</script>
<title>*** LJs LiveOnSat American Football on TV</title>
<meta name="description" content="L.J.s LIVE Sport on Satellite TV">
<meta name="keywords" content="live,football,aussie rules,soccer,schedules,listings,tv,television,satellite,cable,dtt,iptv,rugby,nhl,nfl,hockey,gaa,hurling,sport,boxing">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="verify-v1" content="cRc0erHJmzRfgv1U4yuVbX5WpoAHFzPKqMaLJDLHybo=" />
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-gb">
<link rel="shortcut icon" href="CSS/Shamrock.ico">
<link rel="stylesheet" href="CSS/style14.css" type="text/css" media="screen">
<script>
  (function(w, d, e, u, c, g, a, b){
    w["SSJSConnectorObj"] = w["SSJSConnectorObj"] || {ss_cid : c, domain_info: g};
    a = d.createElement(e);
    a.async = true;
    a.src = u;
    b = d.getElementsByTagName(e)[0];
    b.parentNode.insertBefore(a, b);
    
  })(window,document,"script","https://cdn.perfdrive.com/aperture/aperture.js","bhyl","auto");
    
</script>
<script type="text/javascript" src="js/formatDate.js"></script>
<script type="text/javascript" src="js/Overlib/overlib.js"></script>
<script type="text/javascript" src="js/cookieControl-6.2.min.js"></script>
<script type="text/javascript" src="CSS/swfobject.js"></script>
<script type="text/javascript" src="CSS/menuscript.js"></script>
<script type="text/javascript" src="https://www.google.com/jsapi?key=ABQIAAAAIA4bEf8lwBU_GXLYhPByyRTR_mwIcKGKTnzxAZDp_DfFB29XnxQAj4g9IKMQszplSk0PtrTqaxavnw"></script>
<!--
<script type="text/javascript" src="CSS/gfeedfetcher.js"></script>

<script type="text/javascript" src="CSS/gajaxscroller.js">
/* gAjax RSS Pausing Scroller- (c) Dynamic Drive (www.dynamicdrive.com). Requires "gfeedfetcher.js" class. This notice MUST stay intact for legal use./
/* Bookmark site script- (c) Dynamic Drive (www.dynamicdrive.com). This notice MUST stay intact for legal use. Visit http://www.dynamicdrive.com/ for full source code./
</script>
//-->
<script language="javascript" type="text/javascript">
<!--
/****************************************************
     Author: Eric King
     Url: http://redrival.com/eak/index.shtml
     This script is free to use as long as this info is left in
     Featured on Dynamic Drive script library (http://www.dynamicdrive.com)
****************************************************/
var win=null;
function NewWindow(mypage,myname,w,h,scroll,pos){
if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20}
settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes';
win=window.open(mypage,myname,settings);}
// -->
</script>
<script type="text/javascript">
function bookmarksite(title,url){
if (window.sidebar) // firefox
	window.sidebar.addPanel(title, url, "");
else if(window.opera && window.print){ // opera
	var elem = document.createElement('a');
	elem.setAttribute('href',url);
	elem.setAttribute('title',title);
	elem.setAttribute('rel','sidebar');
	elem.click();
}
else if(document.all)// ie
	window.external.AddFavorite(url, title);
}
</script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9427943540446316"
     crossorigin="anonymous"></script>
</head>
<body bgcolor="#1C2B48" onLoad="writeMenus()" onResize="if (isNS4) nsResizeHandler()" text="#000000" link="#B7D5DD" vlink="#B7D5DD" alink="#B7D5DD"  topmargin="0" leftmargin="0">
<div id="container"><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000; left:0; top:0">
</div>
<table border="0" cellspacing="0" style="border-collapse: collapse" width="1000" bgcolor="#1C2B48"><tr><td>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber2">
<tr>
<td width="100%">
<div align="center">
<center>
<table border="0" cellspacing="0" style="border-collapse: collapse" width="99%" cellpadding="4">
<tr>
<td width="530"><p class="topline"><a target="_top" title="Live On Sat home page" href="http://liveonsat.com">
HOME</a></p></td><td width="530">
<p class="topline" align="right">&nbsp;</td>
</tr>
</table></center>
</div>
</td>
</tr>
<tr>
<td width="100%">
<table border="0" cellpadding="6" cellspacing="0" style="border-collapse: collapse" bordercolor="#E5E5E5" width="100%">
<tr>
<td width="100%" bgcolor="#EEEAEA">&nbsp;</td>
</tr>
</table>
</td>
</tr>
<tr>
<td width="100%">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
<tr>
<td>
  &nbsp;</td> <td>&nbsp;</td><td align="right">
  &nbsp;</td>
</tr>
<tr><td>
  <img border="0" src="images/LJ_banner_mainORIG.jpg" width="633" height="130"></td> <td><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bgcolor="#467AC6" width="100%"><tr>
<td><img border="0" src="images/LJ_banner_topR.jpg" width="430" height="7"></td></tr><tr><td height="88"><script type="text/JavaScript" src="CSS/AdsRotate2014Header.js"></script></td></tr><tr><td>
<map name="FPMap1">
<area target="_blank" href="https://liveonsat.com/submit/submit.php" shape="rect" coords="99, 12, 200, 32">
<area target="_blank" href="http://liveonsat.com/pp_bein_sports.html" shape="rect" coords="293, 12, 378, 32">
<area coords="213, 10, 279, 34" shape="rect" href="https://liveonsat.com/members/login.php">
</map>
    <img border="0" src="images/LJ_banner_bottom.jpg" usemap="#FPMap1" width="430" height="35"></td>
</tr></table></td><td align="right">
  <img border="0" src="images/LJ_banner_2014_right.jpg" width="8" height="130"></td></tr></table>
</td>
</tr>
<tr>
<td width="100%">
<table border="0" cellpadding="9" cellspacing="0" style="border-collapse: collapse" width="95%"><tr>
<td width="100%">
<p align="center"><b><font color="#FF4040" size="2">&nbsp;<u>MEMBERS 1.0</u> 
section now testing. Restrict what you want to display by selecting 
pre-determined Package or Country.</font></b></td></tr></table>
</td>
</tr>
</table>
<table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse" width="100%" bgcolor="#D7D7D7"><tr><td width="100%">
<table border="0" cellpadding="2" cellspacing="0" style="border-collapse: collapse" width="100%"><tr><td width="100%" bgcolor="#B8C4D1"><table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" width="100%"><tr><td valign="top">
<table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bgcolor="#FFFFFF" width="100%">
<tr>
<td>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#C0C0C0" width="100%" id="AutoNumber1">
<tr>
<td>
<p align="center"><span class="disc">Don't ask. There is NO information nor any 
links to unofficial streaming on this site.</span></td>
</tr>
</table>
</td>
</tr>
<tr>
<td bgcolor="#B8C4D1"><span style="font-size: 2px">&nbsp;&nbsp;</span></td>
</tr>
<tr>
<td height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "9599616172";
    google_ad_width = 728;
    google_ad_height = 90;
</script>
<!-- 728 x 90 Leaderboard 1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
</tr>
<tr><td><p align="center"><font size="1" color="#FF4040">
    Website Last updated on
	Sat 10/10/2026 09:04:40 PM GMT +</font></td></tr><tr><td bgcolor="#B8C4D1"><span style="font-size: 2px">&nbsp;&nbsp;</span></td></tr><tr>
<td height="50">
<script type="text/javascript">

function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}

   function changeFunc() {
    var selectBox = document.getElementById("selecttz");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    var selectedOffset = selectBox.options[selectBox.selectedIndex].getAttribute('data-offset');
    setCookie("ljtz",selectedValue,30);
     if (selectedOffset=="0"){selectedOffset = "zero"}
    setCookie("ljoffset",selectedOffset,30);
    location.reload();

   }

  </script>
  
  <!--<div class="floatleft">
  <a href='/usa-nfl-football.php?postponed=0' style='color:#0000EE;font-size:8pt;'>Hide postponed matches</a>
  </div>-->

<div class="floatright">
Timezone =
<select id="selecttz" onChange="changeFunc()" style="font-size: 12px;"><optgroup style="font-size: 12px;"><option data-offset="0" value="UTC"selected=selected >GMT +00:00</option><option data-offset="-39600" value="Pacific/Midway" >(GMT -11:00) Pacific/Midway</option><option data-offset="-39600" value="Pacific/Niue" >(GMT -11:00) Pacific/Niue</option><option data-offset="-39600" value="Pacific/Pago_Pago" >(GMT -11:00) Pacific/Pago_Pago</option><option data-offset="-36000" value="Pacific/Honolulu" >(GMT -10:00) Pacific/Honolulu</option><option data-offset="-36000" value="Pacific/Rarotonga" >(GMT -10:00) Pacific/Rarotonga</option><option data-offset="-36000" value="Pacific/Tahiti" >(GMT -10:00) Pacific/Tahiti</option><option data-offset="-34200" value="Pacific/Marquesas" >(GMT -09:30) Pacific/Marquesas</option><option data-offset="-32400" value="America/Adak" >(GMT -09:00) America/Adak</option><option data-offset="-32400" value="Pacific/Gambier" >(GMT -09:00) Pacific/Gambier</option><option data-offset="-28800" value="America/Anchorage" >(GMT -08:00) America/Anchorage</option><option data-offset="-28800" value="America/Juneau" >(GMT -08:00) America/Juneau</option><option data-offset="-28800" value="America/Metlakatla" >(GMT -08:00) America/Metlakatla</option><option data-offset="-28800" value="America/Nome" >(GMT -08:00) America/Nome</option><option data-offset="-28800" value="America/Sitka" >(GMT -08:00) America/Sitka</option><option data-offset="-28800" value="America/Yakutat" >(GMT -08:00) America/Yakutat</option><option data-offset="-28800" value="Pacific/Pitcairn" >(GMT -08:00) Pacific/Pitcairn</option><option data-offset="-25200" value="America/Creston" >(GMT -07:00) America/Creston</option><option data-offset="-25200" value="America/Dawson" >(GMT -07:00) America/Dawson</option><option data-offset="-25200" value="America/Dawson_Creek" >(GMT -07:00) America/Dawson_Creek</option><option data-offset="-25200" value="America/Fort_Nelson" >(GMT -07:00) America/Fort_Nelson</option><option data-offset="-25200" value="America/Hermosillo" >(GMT -07:00) America/Hermosillo</option><option data-offset="-25200" value="America/Los_Angeles" >(GMT -07:00) America/Los_Angeles</option><option data-offset="-25200" value="America/Phoenix" >(GMT -07:00) America/Phoenix</option><option data-offset="-25200" value="America/Tijuana" >(GMT -07:00) America/Tijuana</option><option data-offset="-25200" value="America/Vancouver" >(GMT -07:00) America/Vancouver</option><option data-offset="-25200" value="America/Whitehorse" >(GMT -07:00) America/Whitehorse</option><option data-offset="-21600" value="America/Belize" >(GMT -06:00) America/Belize</option><option data-offset="-21600" value="America/Boise" >(GMT -06:00) America/Boise</option><option data-offset="-21600" value="America/Cambridge_Bay" >(GMT -06:00) America/Cambridge_Bay</option><option data-offset="-21600" value="America/Chihuahua" >(GMT -06:00) America/Chihuahua</option><option data-offset="-21600" value="America/Costa_Rica" >(GMT -06:00) America/Costa_Rica</option><option data-offset="-21600" value="America/Denver" >(GMT -06:00) America/Denver</option><option data-offset="-21600" value="America/Edmonton" >(GMT -06:00) America/Edmonton</option><option data-offset="-21600" value="America/El_Salvador" >(GMT -06:00) America/El_Salvador</option><option data-offset="-21600" value="America/Guatemala" >(GMT -06:00) America/Guatemala</option><option data-offset="-21600" value="America/Inuvik" >(GMT -06:00) America/Inuvik</option><option data-offset="-21600" value="America/Managua" >(GMT -06:00) America/Managua</option><option data-offset="-21600" value="America/Mazatlan" >(GMT -06:00) America/Mazatlan</option><option data-offset="-21600" value="America/Ojinaga" >(GMT -06:00) America/Ojinaga</option><option data-offset="-21600" value="America/Regina" >(GMT -06:00) America/Regina</option><option data-offset="-21600" value="America/Swift_Current" >(GMT -06:00) America/Swift_Current</option><option data-offset="-21600" value="America/Tegucigalpa" >(GMT -06:00) America/Tegucigalpa</option><option data-offset="-21600" value="America/Yellowknife" >(GMT -06:00) America/Yellowknife</option><option data-offset="-21600" value="Pacific/Galapagos" >(GMT -06:00) Pacific/Galapagos</option><option data-offset="-18000" value="America/Atikokan" >(GMT -05:00) America/Atikokan</option><option data-offset="-18000" value="America/Bahia_Banderas" >(GMT -05:00) America/Bahia_Banderas</option><option data-offset="-18000" value="America/Bogota" >(GMT -05:00) America/Bogota</option><option data-offset="-18000" value="America/Cancun" >(GMT -05:00) America/Cancun</option><option data-offset="-18000" value="America/Cayman" >(GMT -05:00) America/Cayman</option><option data-offset="-18000" value="America/Chicago" >(GMT -05:00) America/Chicago</option><option data-offset="-18000" value="America/Eirunepe" >(GMT -05:00) America/Eirunepe</option><option data-offset="-18000" value="America/Guayaquil" >(GMT -05:00) America/Guayaquil</option><option data-offset="-18000" value="America/Indiana/Knox" >(GMT -05:00) America/Indiana/Knox</option><option data-offset="-18000" value="America/Indiana/Tell_City" >(GMT -05:00) America/Indiana/Tell_City</option><option data-offset="-18000" value="America/Jamaica" >(GMT -05:00) America/Jamaica</option><option data-offset="-18000" value="America/Lima" >(GMT -05:00) America/Lima</option><option data-offset="-18000" value="America/Matamoros" >(GMT -05:00) America/Matamoros</option><option data-offset="-18000" value="America/Menominee" >(GMT -05:00) America/Menominee</option><option data-offset="-18000" value="America/Merida" >(GMT -05:00) America/Merida</option><option data-offset="-18000" value="America/Mexico_City" >(GMT -05:00) America/Mexico_City</option><option data-offset="-18000" value="America/Monterrey" >(GMT -05:00) America/Monterrey</option><option data-offset="-18000" value="America/North_Dakota/Beulah" >(GMT -05:00) America/North_Dakota/Beulah</option><option data-offset="-18000" value="America/North_Dakota/Center" >(GMT -05:00) America/North_Dakota/Center</option><option data-offset="-18000" value="America/North_Dakota/New_Salem" >(GMT -05:00) America/North_Dakota/New_Salem</option><option data-offset="-18000" value="America/Panama" >(GMT -05:00) America/Panama</option><option data-offset="-18000" value="America/Rainy_River" >(GMT -05:00) America/Rainy_River</option><option data-offset="-18000" value="America/Rankin_Inlet" >(GMT -05:00) America/Rankin_Inlet</option><option data-offset="-18000" value="America/Resolute" >(GMT -05:00) America/Resolute</option><option data-offset="-18000" value="America/Rio_Branco" >(GMT -05:00) America/Rio_Branco</option><option data-offset="-18000" value="America/Winnipeg" >(GMT -05:00) America/Winnipeg</option><option data-offset="-18000" value="Pacific/Easter" >(GMT -05:00) Pacific/Easter</option><option data-offset="-14400" value="America/Anguilla" >(GMT -04:00) America/Anguilla</option><option data-offset="-14400" value="America/Antigua" >(GMT -04:00) America/Antigua</option><option data-offset="-14400" value="America/Aruba" >(GMT -04:00) America/Aruba</option><option data-offset="-14400" value="America/Barbados" >(GMT -04:00) America/Barbados</option><option data-offset="-14400" value="America/Blanc-Sablon" >(GMT -04:00) America/Blanc-Sablon</option><option data-offset="-14400" value="America/Boa_Vista" >(GMT -04:00) America/Boa_Vista</option><option data-offset="-14400" value="America/Campo_Grande" >(GMT -04:00) America/Campo_Grande</option><option data-offset="-14400" value="America/Caracas" >(GMT -04:00) America/Caracas</option><option data-offset="-14400" value="America/Cuiaba" >(GMT -04:00) America/Cuiaba</option><option data-offset="-14400" value="America/Curacao" >(GMT -04:00) America/Curacao</option><option data-offset="-14400" value="America/Detroit" >(GMT -04:00) America/Detroit</option><option data-offset="-14400" value="America/Dominica" >(GMT -04:00) America/Dominica</option><option data-offset="-14400" value="America/Grand_Turk" >(GMT -04:00) America/Grand_Turk</option><option data-offset="-14400" value="America/Grenada" >(GMT -04:00) America/Grenada</option><option data-offset="-14400" value="America/Guadeloupe" >(GMT -04:00) America/Guadeloupe</option><option data-offset="-14400" value="America/Guyana" >(GMT -04:00) America/Guyana</option><option data-offset="-14400" value="America/Havana" >(GMT -04:00) America/Havana</option><option data-offset="-14400" value="America/Indiana/Indianapolis" >(GMT -04:00) America/Indiana/Indianapolis</option><option data-offset="-14400" value="America/Indiana/Marengo" >(GMT -04:00) America/Indiana/Marengo</option><option data-offset="-14400" value="America/Indiana/Petersburg" >(GMT -04:00) America/Indiana/Petersburg</option><option data-offset="-14400" value="America/Indiana/Vevay" >(GMT -04:00) America/Indiana/Vevay</option><option data-offset="-14400" value="America/Indiana/Vincennes" >(GMT -04:00) America/Indiana/Vincennes</option><option data-offset="-14400" value="America/Indiana/Winamac" >(GMT -04:00) America/Indiana/Winamac</option><option data-offset="-14400" value="America/Iqaluit" >(GMT -04:00) America/Iqaluit</option><option data-offset="-14400" value="America/Kentucky/Louisville" >(GMT -04:00) America/Kentucky/Louisville</option><option data-offset="-14400" value="America/Kentucky/Monticello" >(GMT -04:00) America/Kentucky/Monticello</option><option data-offset="-14400" value="America/Kralendijk" >(GMT -04:00) America/Kralendijk</option><option data-offset="-14400" value="America/La_Paz" >(GMT -04:00) America/La_Paz</option><option data-offset="-14400" value="America/Lower_Princes" >(GMT -04:00) America/Lower_Princes</option><option data-offset="-14400" value="America/Manaus" >(GMT -04:00) America/Manaus</option><option data-offset="-14400" value="America/Marigot" >(GMT -04:00) America/Marigot</option><option data-offset="-14400" value="America/Martinique" >(GMT -04:00) America/Martinique</option><option data-offset="-14400" value="America/Montserrat" >(GMT -04:00) America/Montserrat</option><option data-offset="-14400" value="America/Nassau" >(GMT -04:00) America/Nassau</option><option data-offset="-14400" value="America/New_York" >(GMT -04:00) America/New_York</option><option data-offset="-14400" value="America/Nipigon" >(GMT -04:00) America/Nipigon</option><option data-offset="-14400" value="America/Pangnirtung" >(GMT -04:00) America/Pangnirtung</option><option data-offset="-14400" value="America/Port-au-Prince" >(GMT -04:00) America/Port-au-Prince</option><option data-offset="-14400" value="America/Port_of_Spain" >(GMT -04:00) America/Port_of_Spain</option><option data-offset="-14400" value="America/Porto_Velho" >(GMT -04:00) America/Porto_Velho</option><option data-offset="-14400" value="America/Puerto_Rico" >(GMT -04:00) America/Puerto_Rico</option><option data-offset="-14400" value="America/Santo_Domingo" >(GMT -04:00) America/Santo_Domingo</option><option data-offset="-14400" value="America/St_Barthelemy" >(GMT -04:00) America/St_Barthelemy</option><option data-offset="-14400" value="America/St_Kitts" >(GMT -04:00) America/St_Kitts</option><option data-offset="-14400" value="America/St_Lucia" >(GMT -04:00) America/St_Lucia</option><option data-offset="-14400" value="America/St_Thomas" >(GMT -04:00) America/St_Thomas</option><option data-offset="-14400" value="America/St_Vincent" >(GMT -04:00) America/St_Vincent</option><option data-offset="-14400" value="America/Thunder_Bay" >(GMT -04:00) America/Thunder_Bay</option><option data-offset="-14400" value="America/Toronto" >(GMT -04:00) America/Toronto</option><option data-offset="-14400" value="America/Tortola" >(GMT -04:00) America/Tortola</option><option data-offset="-10800" value="America/Araguaina" >(GMT -03:00) America/Araguaina</option><option data-offset="-10800" value="America/Argentina/Buenos_Aires" >(GMT -03:00) America/Argentina/Buenos_Aires</option><option data-offset="-10800" value="America/Argentina/Catamarca" >(GMT -03:00) America/Argentina/Catamarca</option><option data-offset="-10800" value="America/Argentina/Cordoba" >(GMT -03:00) America/Argentina/Cordoba</option><option data-offset="-10800" value="America/Argentina/Jujuy" >(GMT -03:00) America/Argentina/Jujuy</option><option data-offset="-10800" value="America/Argentina/La_Rioja" >(GMT -03:00) America/Argentina/La_Rioja</option><option data-offset="-10800" value="America/Argentina/Mendoza" >(GMT -03:00) America/Argentina/Mendoza</option><option data-offset="-10800" value="America/Argentina/Rio_Gallegos" >(GMT -03:00) America/Argentina/Rio_Gallegos</option><option data-offset="-10800" value="America/Argentina/Salta" >(GMT -03:00) America/Argentina/Salta</option><option data-offset="-10800" value="America/Argentina/San_Juan" >(GMT -03:00) America/Argentina/San_Juan</option><option data-offset="-10800" value="America/Argentina/San_Luis" >(GMT -03:00) America/Argentina/San_Luis</option><option data-offset="-10800" value="America/Argentina/Tucuman" >(GMT -03:00) America/Argentina/Tucuman</option><option data-offset="-10800" value="America/Argentina/Ushuaia" >(GMT -03:00) America/Argentina/Ushuaia</option><option data-offset="-10800" value="America/Asuncion" >(GMT -03:00) America/Asuncion</option><option data-offset="-10800" value="America/Bahia" >(GMT -03:00) America/Bahia</option><option data-offset="-10800" value="America/Belem" >(GMT -03:00) America/Belem</option><option data-offset="-10800" value="America/Cayenne" >(GMT -03:00) America/Cayenne</option><option data-offset="-10800" value="America/Fortaleza" >(GMT -03:00) America/Fortaleza</option><option data-offset="-10800" value="America/Glace_Bay" >(GMT -03:00) America/Glace_Bay</option><option data-offset="-10800" value="America/Goose_Bay" >(GMT -03:00) America/Goose_Bay</option><option data-offset="-10800" value="America/Halifax" >(GMT -03:00) America/Halifax</option><option data-offset="-10800" value="America/Maceio" >(GMT -03:00) America/Maceio</option><option data-offset="-10800" value="America/Moncton" >(GMT -03:00) America/Moncton</option><option data-offset="-10800" value="America/Montevideo" >(GMT -03:00) America/Montevideo</option><option data-offset="-10800" value="America/Paramaribo" >(GMT -03:00) America/Paramaribo</option><option data-offset="-10800" value="America/Punta_Arenas" >(GMT -03:00) America/Punta_Arenas</option><option data-offset="-10800" value="America/Recife" >(GMT -03:00) America/Recife</option><option data-offset="-10800" value="America/Santarem" >(GMT -03:00) America/Santarem</option><option data-offset="-10800" value="America/Santiago" >(GMT -03:00) America/Santiago</option><option data-offset="-10800" value="America/Sao_Paulo" >(GMT -03:00) America/Sao_Paulo</option><option data-offset="-10800" value="America/Thule" >(GMT -03:00) America/Thule</option><option data-offset="-10800" value="Antarctica/Palmer" >(GMT -03:00) Antarctica/Palmer</option><option data-offset="-10800" value="Antarctica/Rothera" >(GMT -03:00) Antarctica/Rothera</option><option data-offset="-10800" value="Atlantic/Bermuda" >(GMT -03:00) Atlantic/Bermuda</option><option data-offset="-10800" value="Atlantic/Stanley" >(GMT -03:00) Atlantic/Stanley</option><option data-offset="-9000" value="America/St_Johns" >(GMT -02:30) America/St_Johns</option><option data-offset="-7200" value="America/Godthab" >(GMT -02:00) America/Godthab</option><option data-offset="-7200" value="America/Miquelon" >(GMT -02:00) America/Miquelon</option><option data-offset="-7200" value="America/Noronha" >(GMT -02:00) America/Noronha</option><option data-offset="-7200" value="Atlantic/South_Georgia" >(GMT -02:00) Atlantic/South_Georgia</option><option data-offset="-3600" value="Atlantic/Cape_Verde" >(GMT -01:00) Atlantic/Cape_Verde</option><option data-offset="0" value="Africa/Abidjan" >(GMT -00:00) Africa/Abidjan</option><option data-offset="0" value="Africa/Accra" >(GMT -00:00) Africa/Accra</option><option data-offset="0" value="Africa/Bamako" >(GMT -00:00) Africa/Bamako</option><option data-offset="0" value="Africa/Banjul" >(GMT -00:00) Africa/Banjul</option><option data-offset="0" value="Africa/Bissau" >(GMT -00:00) Africa/Bissau</option><option data-offset="0" value="Africa/Conakry" >(GMT -00:00) Africa/Conakry</option><option data-offset="0" value="Africa/Dakar" >(GMT -00:00) Africa/Dakar</option><option data-offset="0" value="Africa/Freetown" >(GMT -00:00) Africa/Freetown</option><option data-offset="0" value="Africa/Lome" >(GMT -00:00) Africa/Lome</option><option data-offset="0" value="Africa/Monrovia" >(GMT -00:00) Africa/Monrovia</option><option data-offset="0" value="Africa/Nouakchott" >(GMT -00:00) Africa/Nouakchott</option><option data-offset="0" value="Africa/Ouagadougou" >(GMT -00:00) Africa/Ouagadougou</option><option data-offset="0" value="Africa/Sao_Tome" >(GMT -00:00) Africa/Sao_Tome</option><option data-offset="0" value="America/Danmarkshavn" >(GMT -00:00) America/Danmarkshavn</option><option data-offset="0" value="America/Scoresbysund" >(GMT -00:00) America/Scoresbysund</option><option data-offset="0" value="Atlantic/Azores" >(GMT -00:00) Atlantic/Azores</option><option data-offset="0" value="Atlantic/Reykjavik" >(GMT -00:00) Atlantic/Reykjavik</option><option data-offset="0" value="Atlantic/St_Helena" >(GMT -00:00) Atlantic/St_Helena</option><option data-offset="0" value="UTC" >(GMT -00:00) UTC</option><option data-offset="3600" value="Africa/Algiers" >(GMT +01:00) Africa/Algiers</option><option data-offset="3600" value="Africa/Bangui" >(GMT +01:00) Africa/Bangui</option><option data-offset="3600" value="Africa/Brazzaville" >(GMT +01:00) Africa/Brazzaville</option><option data-offset="3600" value="Africa/Casablanca" >(GMT +01:00) Africa/Casablanca</option><option data-offset="3600" value="Africa/Douala" >(GMT +01:00) Africa/Douala</option><option data-offset="3600" value="Africa/El_Aaiun" >(GMT +01:00) Africa/El_Aaiun</option><option data-offset="3600" value="Africa/Kinshasa" >(GMT +01:00) Africa/Kinshasa</option><option data-offset="3600" value="Africa/Lagos" >(GMT +01:00) Africa/Lagos</option><option data-offset="3600" value="Africa/Libreville" >(GMT +01:00) Africa/Libreville</option><option data-offset="3600" value="Africa/Luanda" >(GMT +01:00) Africa/Luanda</option><option data-offset="3600" value="Africa/Malabo" >(GMT +01:00) Africa/Malabo</option><option data-offset="3600" value="Africa/Ndjamena" >(GMT +01:00) Africa/Ndjamena</option><option data-offset="3600" value="Africa/Niamey" >(GMT +01:00) Africa/Niamey</option><option data-offset="3600" value="Africa/Porto-Novo" >(GMT +01:00) Africa/Porto-Novo</option><option data-offset="3600" value="Africa/Tunis" >(GMT +01:00) Africa/Tunis</option><option data-offset="3600" value="Atlantic/Canary" >(GMT +01:00) Atlantic/Canary</option><option data-offset="3600" value="Atlantic/Faroe" >(GMT +01:00) Atlantic/Faroe</option><option data-offset="3600" value="Atlantic/Madeira" >(GMT +01:00) Atlantic/Madeira</option><option data-offset="3600" value="Europe/Dublin" >(GMT +01:00) Europe/Dublin</option><option data-offset="3600" value="Europe/Guernsey" >(GMT +01:00) Europe/Guernsey</option><option data-offset="3600" value="Europe/Isle_of_Man" >(GMT +01:00) Europe/Isle_of_Man</option><option data-offset="3600" value="Europe/Jersey" >(GMT +01:00) Europe/Jersey</option><option data-offset="3600" value="Europe/Lisbon" >(GMT +01:00) Europe/Lisbon</option><option data-offset="3600" value="Europe/London" >(GMT +01:00) Europe/London</option><option data-offset="7200" value="Africa/Blantyre" >(GMT +02:00) Africa/Blantyre</option><option data-offset="7200" value="Africa/Bujumbura" >(GMT +02:00) Africa/Bujumbura</option><option data-offset="7200" value="Africa/Cairo" >(GMT +02:00) Africa/Cairo</option><option data-offset="7200" value="Africa/Ceuta" >(GMT +02:00) Africa/Ceuta</option><option data-offset="7200" value="Africa/Gaborone" >(GMT +02:00) Africa/Gaborone</option><option data-offset="7200" value="Africa/Harare" >(GMT +02:00) Africa/Harare</option><option data-offset="7200" value="Africa/Johannesburg" >(GMT +02:00) Africa/Johannesburg</option><option data-offset="7200" value="Africa/Khartoum" >(GMT +02:00) Africa/Khartoum</option><option data-offset="7200" value="Africa/Kigali" >(GMT +02:00) Africa/Kigali</option><option data-offset="7200" value="Africa/Lubumbashi" >(GMT +02:00) Africa/Lubumbashi</option><option data-offset="7200" value="Africa/Lusaka" >(GMT +02:00) Africa/Lusaka</option><option data-offset="7200" value="Africa/Maputo" >(GMT +02:00) Africa/Maputo</option><option data-offset="7200" value="Africa/Maseru" >(GMT +02:00) Africa/Maseru</option><option data-offset="7200" value="Africa/Mbabane" >(GMT +02:00) Africa/Mbabane</option><option data-offset="7200" value="Africa/Tripoli" >(GMT +02:00) Africa/Tripoli</option><option data-offset="7200" value="Africa/Windhoek" >(GMT +02:00) Africa/Windhoek</option><option data-offset="7200" value="Antarctica/Troll" >(GMT +02:00) Antarctica/Troll</option><option data-offset="7200" value="Arctic/Longyearbyen" >(GMT +02:00) Arctic/Longyearbyen</option><option data-offset="7200" value="Europe/Amsterdam" >(GMT +02:00) Europe/Amsterdam</option><option data-offset="7200" value="Europe/Andorra" >(GMT +02:00) Europe/Andorra</option><option data-offset="7200" value="Europe/Belgrade" >(GMT +02:00) Europe/Belgrade</option><option data-offset="7200" value="Europe/Berlin" >(GMT +02:00) Europe/Berlin</option><option data-offset="7200" value="Europe/Bratislava" >(GMT +02:00) Europe/Bratislava</option><option data-offset="7200" value="Europe/Brussels" >(GMT +02:00) Europe/Brussels</option><option data-offset="7200" value="Europe/Budapest" >(GMT +02:00) Europe/Budapest</option><option data-offset="7200" value="Europe/Busingen" >(GMT +02:00) Europe/Busingen</option><option data-offset="7200" value="Europe/Copenhagen" >(GMT +02:00) Europe/Copenhagen</option><option data-offset="7200" value="Europe/Gibraltar" >(GMT +02:00) Europe/Gibraltar</option><option data-offset="7200" value="Europe/Kaliningrad" >(GMT +02:00) Europe/Kaliningrad</option><option data-offset="7200" value="Europe/Ljubljana" >(GMT +02:00) Europe/Ljubljana</option><option data-offset="7200" value="Europe/Luxembourg" >(GMT +02:00) Europe/Luxembourg</option><option data-offset="7200" value="Europe/Madrid" >(GMT +02:00) Europe/Madrid</option><option data-offset="7200" value="Europe/Malta" >(GMT +02:00) Europe/Malta</option><option data-offset="7200" value="Europe/Monaco" >(GMT +02:00) Europe/Monaco</option><option data-offset="7200" value="Europe/Oslo" >(GMT +02:00) Europe/Oslo</option><option data-offset="7200" value="Europe/Paris" >(GMT +02:00) Europe/Paris</option><option data-offset="7200" value="Europe/Podgorica" >(GMT +02:00) Europe/Podgorica</option><option data-offset="7200" value="Europe/Prague" >(GMT +02:00) Europe/Prague</option><option data-offset="7200" value="Europe/Rome" >(GMT +02:00) Europe/Rome</option><option data-offset="7200" value="Europe/San_Marino" >(GMT +02:00) Europe/San_Marino</option><option data-offset="7200" value="Europe/Sarajevo" >(GMT +02:00) Europe/Sarajevo</option><option data-offset="7200" value="Europe/Skopje" >(GMT +02:00) Europe/Skopje</option><option data-offset="7200" value="Europe/Stockholm" >(GMT +02:00) Europe/Stockholm</option><option data-offset="7200" value="Europe/Tirane" >(GMT +02:00) Europe/Tirane</option><option data-offset="7200" value="Europe/Vaduz" >(GMT +02:00) Europe/Vaduz</option><option data-offset="7200" value="Europe/Vatican" >(GMT +02:00) Europe/Vatican</option><option data-offset="7200" value="Europe/Vienna" >(GMT +02:00) Europe/Vienna</option><option data-offset="7200" value="Europe/Warsaw" >(GMT +02:00) Europe/Warsaw</option><option data-offset="7200" value="Europe/Zagreb" >(GMT +02:00) Europe/Zagreb</option><option data-offset="7200" value="Europe/Zurich" >(GMT +02:00) Europe/Zurich</option><option data-offset="10800" value="Africa/Addis_Ababa" >(GMT +03:00) Africa/Addis_Ababa</option><option data-offset="10800" value="Africa/Asmara" >(GMT +03:00) Africa/Asmara</option><option data-offset="10800" value="Africa/Dar_es_Salaam" >(GMT +03:00) Africa/Dar_es_Salaam</option><option data-offset="10800" value="Africa/Djibouti" >(GMT +03:00) Africa/Djibouti</option><option data-offset="10800" value="Africa/Juba" >(GMT +03:00) Africa/Juba</option><option data-offset="10800" value="Africa/Kampala" >(GMT +03:00) Africa/Kampala</option><option data-offset="10800" value="Africa/Mogadishu" >(GMT +03:00) Africa/Mogadishu</option><option data-offset="10800" value="Africa/Nairobi" >(GMT +03:00) Africa/Nairobi</option><option data-offset="10800" value="Antarctica/Syowa" >(GMT +03:00) Antarctica/Syowa</option><option data-offset="10800" value="Asia/Aden" >(GMT +03:00) Asia/Aden</option><option data-offset="10800" value="Asia/Amman" >(GMT +03:00) Asia/Amman</option><option data-offset="10800" value="Asia/Baghdad" >(GMT +03:00) Asia/Baghdad</option><option data-offset="10800" value="Asia/Bahrain" >(GMT +03:00) Asia/Bahrain</option><option data-offset="10800" value="Asia/Beirut" >(GMT +03:00) Asia/Beirut</option><option data-offset="10800" value="Asia/Damascus" >(GMT +03:00) Asia/Damascus</option><option data-offset="10800" value="Asia/Famagusta" >(GMT +03:00) Asia/Famagusta</option><option data-offset="10800" value="Asia/Gaza" >(GMT +03:00) Asia/Gaza</option><option data-offset="10800" value="Asia/Hebron" >(GMT +03:00) Asia/Hebron</option><option data-offset="10800" value="Asia/Jerusalem" >(GMT +03:00) Asia/Jerusalem</option><option data-offset="10800" value="Asia/Kuwait" >(GMT +03:00) Asia/Kuwait</option><option data-offset="10800" value="Asia/Nicosia" >(GMT +03:00) Asia/Nicosia</option><option data-offset="10800" value="Asia/Qatar" >(GMT +03:00) Asia/Qatar</option><option data-offset="10800" value="Asia/Riyadh" >(GMT +03:00) Asia/Riyadh</option><option data-offset="10800" value="Europe/Athens" >(GMT +03:00) Europe/Athens</option><option data-offset="10800" value="Europe/Bucharest" >(GMT +03:00) Europe/Bucharest</option><option data-offset="10800" value="Europe/Chisinau" >(GMT +03:00) Europe/Chisinau</option><option data-offset="10800" value="Europe/Helsinki" >(GMT +03:00) Europe/Helsinki</option><option data-offset="10800" value="Europe/Istanbul" >(GMT +03:00) Europe/Istanbul</option><option data-offset="10800" value="Europe/Kiev" >(GMT +03:00) Europe/Kiev</option><option data-offset="10800" value="Europe/Kirov" >(GMT +03:00) Europe/Kirov</option><option data-offset="10800" value="Europe/Mariehamn" >(GMT +03:00) Europe/Mariehamn</option><option data-offset="10800" value="Europe/Minsk" >(GMT +03:00) Europe/Minsk</option><option data-offset="10800" value="Europe/Moscow" >(GMT +03:00) Europe/Moscow</option><option data-offset="10800" value="Europe/Riga" >(GMT +03:00) Europe/Riga</option><option data-offset="10800" value="Europe/Simferopol" >(GMT +03:00) Europe/Simferopol</option><option data-offset="10800" value="Europe/Sofia" >(GMT +03:00) Europe/Sofia</option><option data-offset="10800" value="Europe/Tallinn" >(GMT +03:00) Europe/Tallinn</option><option data-offset="10800" value="Europe/Uzhgorod" >(GMT +03:00) Europe/Uzhgorod</option><option data-offset="10800" value="Europe/Vilnius" >(GMT +03:00) Europe/Vilnius</option><option data-offset="10800" value="Europe/Zaporozhye" >(GMT +03:00) Europe/Zaporozhye</option><option data-offset="10800" value="Indian/Antananarivo" >(GMT +03:00) Indian/Antananarivo</option><option data-offset="10800" value="Indian/Comoro" >(GMT +03:00) Indian/Comoro</option><option data-offset="10800" value="Indian/Mayotte" >(GMT +03:00) Indian/Mayotte</option><option data-offset="12600" value="Asia/Tehran" >(GMT +03:30) Asia/Tehran</option><option data-offset="14400" value="Asia/Baku" >(GMT +04:00) Asia/Baku</option><option data-offset="14400" value="Asia/Dubai" >(GMT +04:00) Asia/Dubai</option><option data-offset="14400" value="Asia/Muscat" >(GMT +04:00) Asia/Muscat</option><option data-offset="14400" value="Asia/Tbilisi" >(GMT +04:00) Asia/Tbilisi</option><option data-offset="14400" value="Asia/Yerevan" >(GMT +04:00) Asia/Yerevan</option><option data-offset="14400" value="Europe/Astrakhan" >(GMT +04:00) Europe/Astrakhan</option><option data-offset="14400" value="Europe/Samara" >(GMT +04:00) Europe/Samara</option><option data-offset="14400" value="Europe/Saratov" >(GMT +04:00) Europe/Saratov</option><option data-offset="14400" value="Europe/Ulyanovsk" >(GMT +04:00) Europe/Ulyanovsk</option><option data-offset="14400" value="Europe/Volgograd" >(GMT +04:00) Europe/Volgograd</option><option data-offset="14400" value="Indian/Mahe" >(GMT +04:00) Indian/Mahe</option><option data-offset="14400" value="Indian/Mauritius" >(GMT +04:00) Indian/Mauritius</option><option data-offset="14400" value="Indian/Reunion" >(GMT +04:00) Indian/Reunion</option><option data-offset="16200" value="Asia/Kabul" >(GMT +04:30) Asia/Kabul</option><option data-offset="18000" value="Antarctica/Mawson" >(GMT +05:00) Antarctica/Mawson</option><option data-offset="18000" value="Asia/Aqtau" >(GMT +05:00) Asia/Aqtau</option><option data-offset="18000" value="Asia/Aqtobe" >(GMT +05:00) Asia/Aqtobe</option><option data-offset="18000" value="Asia/Ashgabat" >(GMT +05:00) Asia/Ashgabat</option><option data-offset="18000" value="Asia/Atyrau" >(GMT +05:00) Asia/Atyrau</option><option data-offset="18000" value="Asia/Dushanbe" >(GMT +05:00) Asia/Dushanbe</option><option data-offset="18000" value="Asia/Karachi" >(GMT +05:00) Asia/Karachi</option><option data-offset="18000" value="Asia/Oral" >(GMT +05:00) Asia/Oral</option><option data-offset="18000" value="Asia/Qyzylorda" >(GMT +05:00) Asia/Qyzylorda</option><option data-offset="18000" value="Asia/Samarkand" >(GMT +05:00) Asia/Samarkand</option><option data-offset="18000" value="Asia/Tashkent" >(GMT +05:00) Asia/Tashkent</option><option data-offset="18000" value="Asia/Yekaterinburg" >(GMT +05:00) Asia/Yekaterinburg</option><option data-offset="18000" value="Indian/Kerguelen" >(GMT +05:00) Indian/Kerguelen</option><option data-offset="18000" value="Indian/Maldives" >(GMT +05:00) Indian/Maldives</option><option data-offset="19800" value="Asia/Colombo" >(GMT +05:30) Asia/Colombo</option><option data-offset="19800" value="Asia/Kolkata" >(GMT +05:30) Asia/Kolkata</option><option data-offset="20700" value="Asia/Kathmandu" >(GMT +05:45) Asia/Kathmandu</option><option data-offset="21600" value="Antarctica/Vostok" >(GMT +06:00) Antarctica/Vostok</option><option data-offset="21600" value="Asia/Almaty" >(GMT +06:00) Asia/Almaty</option><option data-offset="21600" value="Asia/Bishkek" >(GMT +06:00) Asia/Bishkek</option><option data-offset="21600" value="Asia/Dhaka" >(GMT +06:00) Asia/Dhaka</option><option data-offset="21600" value="Asia/Omsk" >(GMT +06:00) Asia/Omsk</option><option data-offset="21600" value="Asia/Qostanay" >(GMT +06:00) Asia/Qostanay</option><option data-offset="21600" value="Asia/Thimphu" >(GMT +06:00) Asia/Thimphu</option><option data-offset="21600" value="Asia/Urumqi" >(GMT +06:00) Asia/Urumqi</option><option data-offset="21600" value="Indian/Chagos" >(GMT +06:00) Indian/Chagos</option><option data-offset="23400" value="Asia/Yangon" >(GMT +06:30) Asia/Yangon</option><option data-offset="23400" value="Indian/Cocos" >(GMT +06:30) Indian/Cocos</option><option data-offset="25200" value="Antarctica/Davis" >(GMT +07:00) Antarctica/Davis</option><option data-offset="25200" value="Asia/Bangkok" >(GMT +07:00) Asia/Bangkok</option><option data-offset="25200" value="Asia/Barnaul" >(GMT +07:00) Asia/Barnaul</option><option data-offset="25200" value="Asia/Ho_Chi_Minh" >(GMT +07:00) Asia/Ho_Chi_Minh</option><option data-offset="25200" value="Asia/Hovd" >(GMT +07:00) Asia/Hovd</option><option data-offset="25200" value="Asia/Jakarta" >(GMT +07:00) Asia/Jakarta</option><option data-offset="25200" value="Asia/Krasnoyarsk" >(GMT +07:00) Asia/Krasnoyarsk</option><option data-offset="25200" value="Asia/Novokuznetsk" >(GMT +07:00) Asia/Novokuznetsk</option><option data-offset="25200" value="Asia/Novosibirsk" >(GMT +07:00) Asia/Novosibirsk</option><option data-offset="25200" value="Asia/Phnom_Penh" >(GMT +07:00) Asia/Phnom_Penh</option><option data-offset="25200" value="Asia/Pontianak" >(GMT +07:00) Asia/Pontianak</option><option data-offset="25200" value="Asia/Tomsk" >(GMT +07:00) Asia/Tomsk</option><option data-offset="25200" value="Asia/Vientiane" >(GMT +07:00) Asia/Vientiane</option><option data-offset="25200" value="Indian/Christmas" >(GMT +07:00) Indian/Christmas</option><option data-offset="28800" value="Antarctica/Casey" >(GMT +08:00) Antarctica/Casey</option><option data-offset="28800" value="Asia/Brunei" >(GMT +08:00) Asia/Brunei</option><option data-offset="28800" value="Asia/Choibalsan" >(GMT +08:00) Asia/Choibalsan</option><option data-offset="28800" value="Asia/Hong_Kong" >(GMT +08:00) Asia/Hong_Kong</option><option data-offset="28800" value="Asia/Irkutsk" >(GMT +08:00) Asia/Irkutsk</option><option data-offset="28800" value="Asia/Kuala_Lumpur" >(GMT +08:00) Asia/Kuala_Lumpur</option><option data-offset="28800" value="Asia/Kuching" >(GMT +08:00) Asia/Kuching</option><option data-offset="28800" value="Asia/Macau" >(GMT +08:00) Asia/Macau</option><option data-offset="28800" value="Asia/Makassar" >(GMT +08:00) Asia/Makassar</option><option data-offset="28800" value="Asia/Manila" >(GMT +08:00) Asia/Manila</option><option data-offset="28800" value="Asia/Shanghai" >(GMT +08:00) Asia/Shanghai</option><option data-offset="28800" value="Asia/Singapore" >(GMT +08:00) Asia/Singapore</option><option data-offset="28800" value="Asia/Taipei" >(GMT +08:00) Asia/Taipei</option><option data-offset="28800" value="Asia/Ulaanbaatar" >(GMT +08:00) Asia/Ulaanbaatar</option><option data-offset="28800" value="Australia/Perth" >(GMT +08:00) Australia/Perth</option><option data-offset="31500" value="Australia/Eucla" >(GMT +08:45) Australia/Eucla</option><option data-offset="32400" value="Asia/Chita" >(GMT +09:00) Asia/Chita</option><option data-offset="32400" value="Asia/Dili" >(GMT +09:00) Asia/Dili</option><option data-offset="32400" value="Asia/Jayapura" >(GMT +09:00) Asia/Jayapura</option><option data-offset="32400" value="Asia/Khandyga" >(GMT +09:00) Asia/Khandyga</option><option data-offset="32400" value="Asia/Pyongyang" >(GMT +09:00) Asia/Pyongyang</option><option data-offset="32400" value="Asia/Seoul" >(GMT +09:00) Asia/Seoul</option><option data-offset="32400" value="Asia/Tokyo" >(GMT +09:00) Asia/Tokyo</option><option data-offset="32400" value="Asia/Yakutsk" >(GMT +09:00) Asia/Yakutsk</option><option data-offset="32400" value="Pacific/Palau" >(GMT +09:00) Pacific/Palau</option><option data-offset="34200" value="Australia/Darwin" >(GMT +09:30) Australia/Darwin</option><option data-offset="36000" value="Antarctica/DumontDUrville" >(GMT +10:00) Antarctica/DumontDUrville</option><option data-offset="36000" value="Asia/Ust-Nera" >(GMT +10:00) Asia/Ust-Nera</option><option data-offset="36000" value="Asia/Vladivostok" >(GMT +10:00) Asia/Vladivostok</option><option data-offset="36000" value="Australia/Brisbane" >(GMT +10:00) Australia/Brisbane</option><option data-offset="36000" value="Australia/Lindeman" >(GMT +10:00) Australia/Lindeman</option><option data-offset="36000" value="Pacific/Chuuk" >(GMT +10:00) Pacific/Chuuk</option><option data-offset="36000" value="Pacific/Guam" >(GMT +10:00) Pacific/Guam</option><option data-offset="36000" value="Pacific/Port_Moresby" >(GMT +10:00) Pacific/Port_Moresby</option><option data-offset="36000" value="Pacific/Saipan" >(GMT +10:00) Pacific/Saipan</option><option data-offset="37800" value="Australia/Adelaide" >(GMT +10:30) Australia/Adelaide</option><option data-offset="37800" value="Australia/Broken_Hill" >(GMT +10:30) Australia/Broken_Hill</option><option data-offset="39600" value="Antarctica/Macquarie" >(GMT +11:00) Antarctica/Macquarie</option><option data-offset="39600" value="Asia/Magadan" >(GMT +11:00) Asia/Magadan</option><option data-offset="39600" value="Asia/Sakhalin" >(GMT +11:00) Asia/Sakhalin</option><option data-offset="39600" value="Asia/Srednekolymsk" >(GMT +11:00) Asia/Srednekolymsk</option><option data-offset="39600" value="Australia/Currie" >(GMT +11:00) Australia/Currie</option><option data-offset="39600" value="Australia/Hobart" >(GMT +11:00) Australia/Hobart</option><option data-offset="39600" value="Australia/Lord_Howe" >(GMT +11:00) Australia/Lord_Howe</option><option data-offset="39600" value="Australia/Melbourne" >(GMT +11:00) Australia/Melbourne</option><option data-offset="39600" value="Australia/Sydney" >(GMT +11:00) Australia/Sydney</option><option data-offset="39600" value="Pacific/Bougainville" >(GMT +11:00) Pacific/Bougainville</option><option data-offset="39600" value="Pacific/Efate" >(GMT +11:00) Pacific/Efate</option><option data-offset="39600" value="Pacific/Guadalcanal" >(GMT +11:00) Pacific/Guadalcanal</option><option data-offset="39600" value="Pacific/Kosrae" >(GMT +11:00) Pacific/Kosrae</option><option data-offset="39600" value="Pacific/Norfolk" >(GMT +11:00) Pacific/Norfolk</option><option data-offset="39600" value="Pacific/Noumea" >(GMT +11:00) Pacific/Noumea</option><option data-offset="39600" value="Pacific/Pohnpei" >(GMT +11:00) Pacific/Pohnpei</option><option data-offset="43200" value="Asia/Anadyr" >(GMT +12:00) Asia/Anadyr</option><option data-offset="43200" value="Asia/Kamchatka" >(GMT +12:00) Asia/Kamchatka</option><option data-offset="43200" value="Pacific/Fiji" >(GMT +12:00) Pacific/Fiji</option><option data-offset="43200" value="Pacific/Funafuti" >(GMT +12:00) Pacific/Funafuti</option><option data-offset="43200" value="Pacific/Kwajalein" >(GMT +12:00) Pacific/Kwajalein</option><option data-offset="43200" value="Pacific/Majuro" >(GMT +12:00) Pacific/Majuro</option><option data-offset="43200" value="Pacific/Nauru" >(GMT +12:00) Pacific/Nauru</option><option data-offset="43200" value="Pacific/Tarawa" >(GMT +12:00) Pacific/Tarawa</option><option data-offset="43200" value="Pacific/Wake" >(GMT +12:00) Pacific/Wake</option><option data-offset="43200" value="Pacific/Wallis" >(GMT +12:00) Pacific/Wallis</option><option data-offset="46800" value="Antarctica/McMurdo" >(GMT +13:00) Antarctica/McMurdo</option><option data-offset="46800" value="Pacific/Auckland" >(GMT +13:00) Pacific/Auckland</option><option data-offset="46800" value="Pacific/Enderbury" >(GMT +13:00) Pacific/Enderbury</option><option data-offset="46800" value="Pacific/Fakaofo" >(GMT +13:00) Pacific/Fakaofo</option><option data-offset="46800" value="Pacific/Tongatapu" >(GMT +13:00) Pacific/Tongatapu</option><option data-offset="49500" value="Pacific/Chatham" >(GMT +13:45) Pacific/Chatham</option><option data-offset="50400" value="Pacific/Apia" >(GMT +14:00) Pacific/Apia</option><option data-offset="50400" value="Pacific/Kiritimati" >(GMT +14:00) Pacific/Kiritimati</option></optgroup></select>


</div>

<div style="clear:right">    <div class=floatAndClearL><h2 class = sport_head >American Football</h2></div>  <!-- sport_head -->
    <div class=floatAndClearL><h2 class = time_head>Sunday, 11th  October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Jacksonville Jaguars v Philadelphia Eagles</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791725400">
      <!-- around icon 4-->
         ST: 13:30
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.304 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.304 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>                    </table>',CAPTION, 'Arena Premium 5 Srbija HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Arena Premium 5 Srbija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 2 Slovenija HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Arena Sport 2 Slovenija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 5 Hrvatska HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Arena Sport 5 Hrvatska HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col></td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>0</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 7 BiH HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Arena Sport 7 BiH HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank" class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.bein.net/" target="_blank" class = chan_live_iptvcable>              beIN Connect MENA HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA 6 HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">beIN Sports MENA 6 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>13.0&deg;e</td><td class=rest_col>Hotbird 13F</td><td  class=&quot;freq_col&quot;>12.130 H</td><td class=rest_col>30000 - 5/6</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.169 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Magenta Hellas Sport 9 HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Magenta Hellas Sport 9 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>-</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Sky Sport NFL Deutsch HD &nbsp;&ndash;&nbsp;2026-10-11 13:30:00');" onmouseout="return nd();">Sky Sport NFL Deutsch HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">- N F L - R E D - Z O N E -</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791737700">
      <!-- around icon 4-->
         ST: 16:55
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Nagra</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 NDS</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Irdeto</td></tr>                    </table>',CAPTION, 'Arena Sport 1x2 Srbija &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">Arena Sport 1x2 Srbija </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 5 Hrvatska HD &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">Arena Sport 5 Hrvatska HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.758 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport MIX Deutsch HD &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">Sky Sport MIX Deutsch HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>-</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Sky Sport NFL Deutsch HD &nbsp;&ndash;&nbsp;2026-10-11 16:55:00');" onmouseout="return nd();">Sky Sport NFL Deutsch HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">New Orleans Saints v Minnesota Vikings</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank"  class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="https://connect.bein.net/" target="_blank"  class = chan_live_iptvcable>              beIN Connect MENA HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA 6 HD &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">beIN Sports MENA 6 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA English 2 HD &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">beIN Sports MENA English 2 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Washington Commanders v New York Giants</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Tennessee Titans v Houston Texans</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Pittsburgh Steelers v Indianapolis Colts</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">New York Jets v Cleveland Browns</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">New England Patriots v Las Vegas Raiders</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>13.0&deg;e</td><td class=rest_col>Hotbird 13F</td><td  class=&quot;freq_col&quot;>12.130 H</td><td class=rest_col>30000 - 5/6</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.169 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Magenta Hellas Sport 9 HD &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">Magenta Hellas Sport 9 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Miami Dolphins v Cincinnati Bengals</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791738000">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Los Angeles Chargers v Denver Broncos</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791749100">
      <!-- around icon 4-->
         ST: 20:05
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>13.0&deg;e</td><td class=rest_col>Hotbird 13F</td><td  class=&quot;freq_col&quot;>12.130 H</td><td class=rest_col>30000 - 5/6</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.169 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Magenta Hellas Sport 9 HD &nbsp;&ndash;&nbsp;2026-10-11 20:05:00');" onmouseout="return nd();">Magenta Hellas Sport 9 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:05:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:05:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Seattle Seahawks v San Francisco 49ers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791750300">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'Arena Premium 1 Srbija HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Arena Premium 1 Srbija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 2 Slovenija HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Arena Sport 2 Slovenija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank" class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.bein.net/" target="_blank" class = chan_live_iptvcable>              beIN Connect MENA HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA 6 HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">beIN Sports MENA 6 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA English 2 HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">beIN Sports MENA English 2 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Green Bay Packers v Chicago Bears</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791750300">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.304 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.304 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>                    </table>',CAPTION, 'Arena Premium 5 Srbija HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Arena Premium 5 Srbija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 2 Slovenija HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Arena Sport 2 Slovenija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3B</td><td  class=&quot;freq_col&quot;>11.895 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3B</td><td  class=&quot;freq_col&quot;>11.895 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 3 BiH HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Arena Sport 3 BiH HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1N</td><td  class=&quot;freq_col&quot;>11.914 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport 1 Deutsch HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Sky Sport 1 Deutsch HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Arizona Cardinals v Detroit Lions</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791750300">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1N</td><td  class=&quot;freq_col&quot;>11.914 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport 1 Deutsch HD &nbsp;&ndash;&nbsp;2026-10-11 20:25:00');" onmouseout="return nd();">Sky Sport 1 Deutsch HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Monday, 12th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Atlanta Falcons v Baltimore Ravens</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791764400">
      <!-- around icon 4-->
         ST: 00:20
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'Arena Premium 1 Srbija HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Arena Premium 1 Srbija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 1 Hrvatska HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Arena Sport 1 Hrvatska HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 1 Slovenija HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Arena Sport 1 Slovenija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank" class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.bein.net/" target="_blank" class = chan_live_iptvcable>              beIN Connect MENA HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>10.810 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>8.0&deg;w</td><td class=rest_col>Eutelsat 8 West B</td><td  class=&quot;freq_col&quot;>11.054 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA 8 HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">beIN Sports MENA 8 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>25.5&deg;e</td><td class=rest_col>Eshail 2</td><td  class=&quot;freq_col&quot;>11.390 V</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'beIN Sports MENA English 2 HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">beIN Sports MENA English 2 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>13.0&deg;e</td><td class=rest_col>Hotbird 13F</td><td  class=&quot;freq_col&quot;>12.130 H</td><td class=rest_col>30000 - 5/6</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.169 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Magenta Hellas Sport 9 HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Magenta Hellas Sport 9 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>-</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Sky Sport NFL Deutsch HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Sky Sport NFL Deutsch HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1N</td><td  class=&quot;freq_col&quot;>11.914 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport Top Event HD &nbsp;&ndash;&nbsp;2026-10-12 00:20:00');" onmouseout="return nd();">Sky Sport Top Event HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Tuesday, 13th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 5</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Los Angeles Rams v Buffalo Bills</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1791850500">
      <!-- around icon 4-->
         ST: 00:15
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>23.5&deg;e</td><td class=rest_col>Astra 3C</td><td  class=&quot;freq_col&quot;>12.402 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.366 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>                    </table>',CAPTION, 'Arena Premium 1 Srbija HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Arena Premium 1 Srbija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 1 Hrvatska HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Arena Sport 1 Hrvatska HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Arena Sport 1 Slovenija HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Arena Sport 1 Slovenija HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank" class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>13.0&deg;e</td><td class=rest_col>Hotbird 13F</td><td  class=&quot;freq_col&quot;>12.130 H</td><td class=rest_col>30000 - 5/6</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.169 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Magenta Hellas Sport 9 HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Magenta Hellas Sport 9 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>-</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Sky Sport NFL Deutsch HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Sky Sport NFL Deutsch HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1N</td><td  class=&quot;freq_col&quot;>11.914 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport Top Event HD &nbsp;&ndash;&nbsp;2026-10-13 00:15:00');" onmouseout="return nd();">Sky Sport Top Event HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Friday, 16th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Denver Broncos v Seattle Seahawks</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792109700">
      <!-- around icon 4-->
         ST: 00:15
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>16.0&deg;e</td><td class=rest_col>Eutelsat 16A</td><td  class=&quot;freq_col&quot;>11.678 H</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>HD Conax</td></tr>                    </table>',CAPTION, 'Arena Sport 1 Hrvatska HD &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">Arena Sport 1 Hrvatska HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://connect.beinsports.com/france/se-connecter" target="_blank" class = chan_live_iptvcable>              beIN Connect FRANCE 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1M</td><td  class=&quot;freq_col&quot;>11.856 V</td><td class=rest_col>29700 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>5.0&deg;w</td><td class=rest_col>Eutelsat 5 West A</td><td  class=&quot;freq_col&quot;>12.564 V</td><td class=rest_col>29950 - 2/3</td>       <td class=enc_not_live>HD Viaccess</td></tr>                    </table>',CAPTION, 'beIN Sports France 1 HD &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">beIN Sports France 1 HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://plus.rtl.de/video-tv/live-tv/rtl-1"  target="_blank" class = chan_live_free onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>68.5&deg;e</td><td class=rest_col>Intelsat 20</td><td  class=&quot;freq_col&quot;>12.522 V</td><td class=rest_col>30000 - 3/5</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>42.0&deg;e</td><td class=rest_col>Turksat 4A</td><td  class=&quot;freq_col&quot;>11.775 V</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_not_live>Irdeto</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>12.188 H</td><td class=rest_col>27500 - 3/4</td>       <td class=enc_live>Free To Air</td></tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1L</td><td  class=&quot;freq_col&quot;>10.832 H</td><td class=rest_col>22000 - 2/3</td>       <td class=enc_not_live>HD NagraVision</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD VideoGuard</td></tr>            <tr> <td  class=&quot;pos_col&quot;>9.0&deg;e</td><td class=rest_col>Eutelsat 9B</td><td  class=&quot;freq_col&quot;>12.284 H</td><td class=rest_col>27500 - 2/3</td>       <td class=enc_not_live>HD Conax</td></tr>            <tr> <td  class=&quot;pos_col&quot;>4.0&deg;w</td><td class=rest_col>Amos 3</td><td  class=&quot;freq_col&quot;>10.889 V</td><td class=rest_col>30000 - 3/4</td>       <td class=enc_not_live>MPEG-4 Conax</td></tr>                    </table>',CAPTION, 'RTL Deutschland HD &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">RTL Deutschland HD 📺</a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col>-</td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'Sky Sport NFL Deutsch HD &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">Sky Sport NFL Deutsch HD </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="#"  class = chan_live_not_free onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>19.2&deg;e</td><td class=rest_col>Astra 1N</td><td  class=&quot;freq_col&quot;>11.914 H</td><td class=rest_col>27500 - 9/10</td>       <td class=enc_not_live>HD VideoGuard</td></tr>                    </table>',CAPTION, 'Sky Sport Top Event HD &nbsp;&ndash;&nbsp;2026-10-16 00:15:00');" onmouseout="return nd();">Sky Sport Top Event HD </a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Sunday, 18th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Jacksonville Jaguars v Houston Texans</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792330200">
      <!-- around icon 4-->
         ST: 13:30
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 13:30:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 13:30:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Tampa Bay Buccaneers v Pittsburgh Steelers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Philadelphia Eagles v Carolina Panthers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">New York Giants v New Orleans Saints</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">New England Patriots v New York Jets</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Indianapolis Colts v Tennessee Titans</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Cleveland Browns v Baltimore Ravens</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Atlanta Falcons v Chicago Bears</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792342800">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Los Angeles Rams v Arizona Cardinals</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792353900">
      <!-- around icon 4-->
         ST: 20:05
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:05:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:05:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Las Vegas Raiders v Buffalo Bills</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792355100">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Kansas City Chiefs v Los Angeles Chargers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792355100">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-18 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Monday, 19th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Green Bay Packers v Dallas Cowboys</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792369200">
      <!-- around icon 4-->
         ST: 00:20
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-19 00:20:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-19 00:20:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Tuesday, 20th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 6</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">San Francisco 49ers v Washington Commanders</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792455300">
      <!-- around icon 4-->
         ST: 00:15
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-20 00:15:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-20 00:15:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Friday, 23rd October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Chicago Bears v New England Patriots</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792714500">
      <!-- around icon 4-->
         ST: 00:15
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-23 00:15:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-23 00:15:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Sunday, 25th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">New Orleans Saints v Pittsburgh Steelers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792935000">
      <!-- around icon 4-->
         ST: 13:30
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 13:30:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 13:30:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Tennessee Titans v Cleveland Browns</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">New York Jets v Miami Dolphins</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Minnesota Vikings v Indianapolis Colts</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Houston Texans v New York Giants</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Carolina Panthers v Tampa Bay Buccaneers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Baltimore Ravens v Cincinnati Bengals</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Atlanta Falcons v San Francisco 49ers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792947600">
      <!-- around icon 4-->
         ST: 17:00
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 17:00:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Arizona Cardinals v Denver Broncos</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792958700">
      <!-- around icon 4-->
         ST: 20:05
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:05:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:05:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Las Vegas Raiders v Los Angeles Rams</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792959900">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Detroit Lions v Green Bay Packers</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792959900">
      <!-- around icon 4-->
         ST: 20:25
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:25:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-25 20:25:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Monday, 26th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:9pt;font-family:Tahoma, Geneva, sans-serif">Seattle Seahawks v Kansas City Chiefs</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1792974000">
      <!-- around icon 4-->
         ST: 00:20
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-26 00:20:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-26 00:20:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS-->     <div class=floatAndClearL_list><h2 class = time_head>Tuesday, 27th October</h2></div> <!-- time_head -->         <div><span class = comp_head>NFL Regular Season - Round 7</span></div>
       <div class = blockfix >                <!-- block 1-->
    <div class=fix>                 <!-- around fixture and notes 2-->
          <div class=fix_text>               <!-- around fixture text 3-->
              <div class = imgCenter><span><img src="../img/team/asonfl.gif"></span></div>
              <div class = fLeft style="width:270px;text-align:center;background-color:#ffd379;color:#800000;font-size:10pt;font-family:Tahoma, Geneva, sans-serif">Philadelphia Eagles v Dallas Cowboys</div>
              <div class = imgCenter><img src="../img/team/asonfl.gif"></div>
    </div>                  <!-- around fixture text 3 ENDS-->
        <div class=notes></div>
     </div>                  <!-- around fixture and notes 2 ENDS-->

            <div class = fLeft>                <!-- around all of channel types 2-->     <div>             <!-- around channel type group 3-->
       <div class=fLeft_icon_live_l>       <!-- around icon 4-->
         <img src="../img/icon/live3.png"/>
       </div>
     <div class="fLeft_time_live dynamic-time" data-timestamp="1793060100">
      <!-- around icon 4-->
         ST: 00:15
       </div>           <!-- around icon 4 ENDS-->        <div class = fLeft_live>       <!-- around all tables of a channel type 4-->       <table border="0" cellspacing="0" cellpadding="0"><tr><td class=chan_col>&nbsp; <a href="#"  class = chan_live_iptvcable onclick="return false;" onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live>LiveOnSat.com</td></tr>                    </table>',CAPTION, 'NFL Game Pass ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-27 00:15:00');" onmouseout="return nd();">NFL Game Pass ($/geo/R) </a></td><td width = 0></td>
                    </tr></table>       <table border="0" cellspacing="0" cellpadding="0"><tr><td  class=chan_col>&nbsp; <a href="https://www.dazn.com/nfl-game-pass"  target="_blank" class = chan_live_iptvcable onmouseover="return overlib('<table border=&quot;0&quot;cellspacing=&quot;2&quot;cellpadding=&quot;0&quot; class=&quot;tablePad&quot;> <tr class=fieldRow><td class=posH_col width=40><strong>pos</strong></td><td class=rest_col width=90><strong>satellite</strong></td><td class=freqH_col width=50><strong>freq</strong></td><td class=rest_col width=90><strong>symbol</strong></td><td class=rest_col width=90><strong>encryption</strong></td> </tr>            <tr> <td  class=&quot;pos_col&quot;>0.0&deg;</td><td class=rest_col>* IPTV/Stream</td><td  class=&quot;freq_col&quot;>0.000 </td><td class=rest_col></td>       <td class=enc_not_live></td></tr>                    </table>',CAPTION, 'NFL on DAZN ($/geo/R) &nbsp;&ndash;&nbsp;2026-10-27 00:15:00');" onmouseout="return nd();">NFL on DAZN ($/geo/R) 📺</a></td><td width = 0></td>
                    </tr></table>     </div>     <!-- around all tables of a channel type 4/5 ENDS-->
    </div>       <!-- around channel type group 3/4 ENDS-->              </div>      <!-- around all of channel types ENDS 2-->
              
              
   </div>   
   
   <!-- block 1 ENDS--></div></td></tr><tr><td bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;&nbsp;&nbsp;&nbsp; </span> </td></tr><tr><td><p align="center"><span class="pdisc"><br>
Please Note:</span> <span class="disc">
<a target="_top" href="http://liveonsat.com"><font color="#0000FF">LiveOnSat.com</font></a>
Although we try our best to ensure all schedules are accurate,<br>broadcasters can and will change schedules without warning, especially during off season.<br>
Since we cannot physically monitor every single channel, errors will occur from time to time.<br>We thank you for your support and patience in this matter.<br>
&nbsp;</span></td></tr>
<tr>
<td bgcolor="#B8C4D1"><span style="font-size: 2px">&nbsp;&nbsp;</span></td>
</tr>
<tr>
<td height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "9599616172";
    google_ad_width = 728;
    google_ad_height = 90;
</script>
<!-- 728 x 90 Leaderboard 1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
</tr>
<tr><td bgcolor="#B8C4D1"><p align="center">&nbsp;</td>
</tr></table></td><td valign="top" align="right" width="310"><div align="right"><table border="0" cellpadding="2" cellspacing="0" style="border-collapse: collapse" width="305" bgcolor="#D7D7D7">
<tr>
<td width="100%"><span style="font-size: 1pt">&nbsp;</span></td>
</tr>
<tr>
<td width="100%">
<p align="center"><fb:like href="https://liveonsat.com" send="true" width="300" show_faces="true"></fb:like>
</td>
</tr>
<tr>
      <td width="100%"><span style="font-size: 1pt">&nbsp; </span></td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
      <td width="100%" height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "9540887718";
    google_ad_width = 300;
    google_ad_height = 250;
</script>
<!-- 300 x 250 Medium Rectangle 1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
<td width="100%" bgcolor="#B8C4D1">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" bgcolor="#B8C4D1"><tr>
  <td align="center" width="47%">
  <table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" width="100%" bgcolor="#336699"><tr><td><p align="center">
    <a title="LOGIN" href="https://liveonsat.com/members/login.php">
    <font color="#00FFFF">Members LOGIN</font></a></td></tr>
  <tr>
  <td bgcolor="#B8C4D1" height="5"></td>
  </tr>
  <tr>
  <td>
  <p align="center">
  <a title="NBA only" href="sub-football-nfl.php">
    <font color="#FFFF00">NFL ONLY</font></a></td>
  </tr>
  <tr><td bgcolor="#B8C4D1" height="5"></td></tr><tr><td>
  <p align="center"><a title="Submit a Fixture" target="_blank" href="https://liveonsat.com/submit/submit.php">Submit Fixture</a></td></tr></table></td>
  <td align="center" width="5%">&nbsp;</td><td align="center" width="47%">
  <table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" width="100%" bgcolor="#336699">  <tr><td><p align="center">
    <a title="LOGOUT" href="https://liveonsat.com/members/logout.php">
    <font color="#00FF00">Members LOGOUT</font></a></td></tr><tr><td bgcolor="#B8C4D1" height="5"></td>
    </tr><tr><td><p align="center">
  <a title="College Baskteball Only" href="sub-football-ncaa.php">
      <font color="#FFFF00">NCAA ONLY</font></a></td></tr>
  <tr><td bgcolor="#B8C4D1" height="5"></td>
    </tr><tr><td><p align="center">
<a href="mailto:ljsport&#064;liveonsat.com?subject=General Comment">E-MAIL</a></td></tr></table></td></tr></table></td>
</tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
      <td width="100%" height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "3634098574";
    google_ad_width = 300;
    google_ad_height = 600;
</script>
<!-- Tower1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
      <td width="100%" height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "9540887718";
    google_ad_width = 300;
    google_ad_height = 250;
</script>
<!-- 300 x 250 Medium Rectangle 1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1">
      <p style="margin-left: 4"><font size="1"><br>
      External Links:</font></td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1">
      <p style="margin-left: 6"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
      <td width="100%">
      <table border="0" cellpadding="4" cellspacing="0" style="border-collapse: collapse" width="100%">
        <tr>
          <td width="33%"><a target="_blank" href="https://www.fifa.com/">
          <img border="0" src="images/link_fifa.gif" alt="FIFA" hspace="0" width="90" height="35"></a></td>
          <td width="33%">
          <a target="_blank" href="https://www.uefa.com/uefachampionsleague/">
          <img border="0" src="images/link_cl.png" alt="UEFA Champions League" width="90" height="35"></a></td>
          <td width="33%">
          <a target="_blank" href="https://www.uefa.com/uefaeuropaleague/">
          <img border="0" src="images/link_europa.png" alt="UEFA Europa League" width="90" height="35"></a></td>
        </tr>
        <tr>
          <td width="33%">
          <a target="_blank" href="https://www.epcrugby.com/">
<img border="0" src="images/link_EURugby.png" width="90" height="35"></a></td>
          <td width="33%">
          <a target="_blank" href="https://www.nfl.com/">
          <img border="0" src="images/link_NFL.png" width="90" height="35" alt="American National Football League"></a></td>
          <td width="33%">
          <a target="_blank" href="http://www.gaa.ie/">
          <img border="0" src="images/link_gaa.gif" alt="Gaelic Athletic Association" hspace="0" width="90" height="35"></a></td>
        </tr>
        </table>
      </td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
<tr>
      <td width="100%" height="50">
<script type="text/javascript">
    google_ad_client = "ca-pub-9427943540446316";
    google_ad_slot = "3634098574";
    google_ad_width = 300;
    google_ad_height = 600;
</script>
<!-- Tower1 -->
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</td>
    </tr>
<tr>
      <td width="100%" bgcolor="#B8C4D1"><span style="font-size: 1pt">&nbsp;</span></td>
    </tr>
    <tr><td width="100%" bgcolor="#B8C4D1"></td></tr></table></div></td></tr></table><hr color="#959595" size="1"></td></tr></table></td></tr></table>
<div align="center"><center><table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse" width="95%"><tr><td width="100%"><p align="center"><br><br>
<b><a target="_top" title="Live On Sat home page" href="http://liveonsat.com">
<font size="2">HOME PAGE</font></a></b><br>
<font size="1" color="#FFFFFF">
<br>
This website has been tested on: Chrome, Edge, Firefox, Sea Monkey, Explorer, Safari and Opera.<br>
L.J.'s LIVE Football on Satellite TV. LiveOnSat.com. LJ-Sport.com. All Rights 
Reserved. Copyright (c) 1997 - 2026</font><br>
  This site is protected by reCAPTCHA and the Google
    <a href="https://policies.google.com/privacy">Privacy Policy</a> and
    <a href="https://policies.google.com/terms">Terms of Service</a> apply.</font><br>
&nbsp;</p><div align="center"><center><table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse" width="90%"><tr><td><p align="center">
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-6554248-2");
pageTracker._trackPageview();
</script>
</td></tr></table></center></div><div align="center"><center>
<table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse" width="10%">
</tr></table></center></div><div align="center"><center><table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="90%"><tr><td width="100%">
&nbsp;</td></tr></table></center></div></td></tr></table></center>
</div>

    <script type="text/javascript">//<![CDATA[
      cookieControl({
          t: {
              title: '<p>This site uses cookies to store information on your computer.</p>',
              intro: '<p>Some of these cookies are essential to make our site work and others help us to improve by giving us some insight into how the site is being used.</p>',
              full:'<p>These cookies are set when you submit a form, login or interact with the site by doing something that goes beyond clicking some simple links.</p><p>We also use some non-essential cookies to anonymously track visitors or enhance your experience of this site. If you\'re not happy with this, we won\'t set these cookies but some nice features on the site may be unavailable.</p><p>To control third party cookies, you can also <a class="ccc-settings" href="browser-settings" target="_blank">adjust your browser settings.</a></p><p>By using our site you accept the terms of our <a href="https://liveonsat.com/CookiePrivacyPolicy.html">Privacy Policy</a>.</p>'
          },
          position:CookieControl.POS_LEFT,
          style:CookieControl.STYLE_TRIANGLE,
          theme:CookieControl.THEME_LIGHT, // light or dark
          startOpen:true,
          autoHide:7000,
          subdomains:true,
          protectedCookies: [], // list the cookies you do not want deleted, for example ['analytics', 'twitter']
          apiKey: '7624fb8e537b0c392a9ef26302840f4fea2abbe3',
          product: CookieControl.PROD_FREE,
          consentModel: CookieControl.MODEL_INFO,
          onAccept:function(){ccAddAnalytics()},
          onReady:function(){},
          onCookiesAllowed:function(){ccAddAnalytics()},
          onCookiesNotAllowed:function(){}
          });
    
          function ccAddAnalytics() {
            jQuery.getScript("http://www.google-analytics.com/ga.js", function() {
              var GATracker = _gat._createTracker('UA-6554248-2');
              GATracker._trackPageview();
            });
          }
       //]]>
    </script>
</td></tr>
</table>
</div>

<script src="wp-banners.js" type="text/javascript"></script>
<script type="text/javascript">

if(document.getElementById('dciKqgaNSWPx')){
  dciKqgaNSWPx='No';
 
} else {
   alert('Our website is made possible by displaying online advertisements to our visitors. Please consider supporting us by disabling your ad blocker.');
  dciKqgaNSWPx='Yes';
}

if(typeof ga !=='undefined'){
  ga('send','event','Blocking Ads',dciKqgaNSWPx,{'nonInteraction':1});
} else if(typeof _gaq !=='undefined'){
  _gaq.push(['_trackEvent','Blocking Ads',dciKqgaNSWPx,undefined,undefined,true]);
}

</script>
</body>
</html>
